import express from "express";
import multer from "multer";
import path from "path";
import fs from "fs"
const router = express.Router();
// Storage config
import { fileURLToPath } from "url";

// manually recreate __dirname
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const frontendUploadsPath = path.join(__dirname, "../../StoryTime-Frontend/public/uploads");

// Ensure the directory exists
if (!fs.existsSync(frontendUploadsPath)) {
  fs.mkdirSync(frontendUploadsPath, { recursive: true });
}

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, frontendUploadsPath);
  },
  filename: (req, file, cb) => {
    const uniqueName = `${Date.now()}-${file.originalname}`;
    cb(null, uniqueName);
  },
});

const upload = multer({ storage });


//router.get("/all", async (req, res) => {
//   try {
//    // console.log("hi");
//     const authors = await User.find({}, "name bio profilePicture");
//     //console.log(authors);

//     res.json(
//       authors.map((author) => ({
//         _id: author._id,
//         name: author.name,
//         bio: author.bio || "",
//         profileImage: author.profilePicture || "/default.jpg", // fallback image
//       }))
//     );
//   } catch (error) {
//     console.error("Error in /all route:", error);
//     res
//       .status(500)
//       .json({ message: "Error fetching user profile", error: error.message });
//   }
// });
// router.get("/leaderboard", async (req, res) => {
//   try {
//     const topUsers = await User.find()
//       .sort({ contributions: -1 })
//       .limit(10)
//       .select("name contributions profilePicture");
//     res.json(topUsers);
//   } catch (error) {
//     res
//       .status(500)
//       .json({ message: "Error fetching leaderboard", error: error.message });
//   }
// });

/**
 * ✅ User Registration
 */
// router.post("/register",upload.single("profilePicture"), async (req, res) => {
//   try {
//     const { name, email, password, googleId } = req.body;
//     //console.log("profile Picture - ", req.file)

//     if (!email || (!password && !googleId)) {
//       return res.status(400).json({ message: "Missing required fields" });
//     }

//     let user = await User.findOne({ email });
//     if (user) {
//       return res.status(400).json({ message: "User already exists" });
//     }

//     const newUser = new User({
//       name,
//       email,
//       password,
//       googleId,
//       profilePicture: req.file ? `/uploads/${req.file.filename}` : "",
//     });
//     await newUser.save();

//     const token = generateToken(newUser._id);
//     res.status(201).json({
//       _id: newUser._id,
//       name: newUser.name,
//       email: newUser.email,
//       token,
//     });
//   } catch (error) {
//     res
//       .status(500)
//       .json({ message: "Error registering user", error: error.message });
//   }
// });



/**
 * ✅ Update User Profile (Protected)
 */

router.post("/change-pic", upload.single("profilePicture"), (req, res) => {
  if (!req.file) return res.status(400).json({ message: "No file uploaded" });

  // return public path
  res.json({
    message: "Upload successful",
    filePath: `/uploads/${req.file.filename}`,
  });
});


export default router;
